# MARIGOLD

**M**ultiphase **A**nalysis of **R**aw **I**nformation for **G**lobal **O**r **L**ocal **D**ata

Library to help facilitate the processing, modeling, and visualiztion of two-phase conductivity probe data.